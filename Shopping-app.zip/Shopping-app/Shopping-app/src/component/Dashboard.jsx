import axios from "axios";
import React, { useEffect, useState } from "react";
import "../Style/Dashboard.css";
import Star from "./star";

function Dashboard() {
  let [item, setItem] = useState([]);
  useEffect(() => {
    axios
      .get("http://localhost:1001/product")
      .then((res) => {
        console.log(res.data);
        setItem(res.data);
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);
  return (
    <>
      <div className="shopping">
        {item.map((item) => {
          return (
            <>
              <div className="productshop">
                <div className="thumbnail">
                  <img src={item.pr_img} alt="" />
                </div>
                <div className="details">
                  <b>{item.p_brand}</b>||<b>{item.p_category}</b>
                  <strike>M.R.P:{item.pr_price}</strike>
                  <span>{item.pr_price - item.pr_price * 0.15}/-</span>
                </div>
                <div className="product-info">
                  <div className="rating">
                    {item.pr_rating}
                    <Star />
                  </div>
                  <div className="stock">{item.pr_stock}</div>
                </div>
                <button id="btn1"> Edit</button>
                <button id="btn2">Remove</button>
              </div>
            </>
          );
        })}
      </div>
    </>
  );
}

export default Dashboard;
