import { Route, Routes } from "react-router-dom";
import Navbar from "./Navbar";
import AddProduct from "./AddProduct";
import Dashboard from "./Dashboard";
function AdminHomepage() {
  return (
    <div className="AdminHomePage">
      <Navbar />
      <Routes>
        <Route path="/add-products" element={<AddProduct />} />
        <Route path="/" element={<Dashboard />} />
      </Routes>
    </div>
  );
}
export default AdminHomepage;
