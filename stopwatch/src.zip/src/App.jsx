import Stopwatch from "./stopwatch/Stopwatch";

function App() {
  return (
    <div>
      <Stopwatch></Stopwatch>
    </div>
  );
}

export default App;
